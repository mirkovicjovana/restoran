<?php
	
	//const koje se koriste za pristup tabelama i kolonama u bazi
    define("TBL_JELA", "jelo");
    define("COL_ID_JELA","id");
    define("COL_NAZIV", "naziv");
    define("COL_CENA", "cena");
    define("COL_OPIS", "opis");
    define("TBL_POR", "porudzbina");
    define("COL_ID_POR", "id_por");
    define("COL_EMAIL", "email");
    define("COL_IME", "ime");
    define("COL_PREZIME", "prezime");
    define("COL_ADRESA", "adresa");
    define("COL_TEL", "telefon");
    define("COL_PLACANJE", "nacin_placanja");
    define("COL_ID_KOR_P", "id_kor");
    define("TBL_KOR", "korpa");
    define("COL_ID_KOR", "id_korpe");
    define("COL_KOL", "kolicina");
    define("COL_ID_JELA_K", "id_hela");
    define("TBL_REZ", "rezervacija");
    define("COL_REZ_EMAIL", "rez_email");
    define("COL_REZ_IME", "rez_ime");
    define("COL_REZ_PREZIME", "rez_prezime");
    define("COL_REZ_DATUM", "datum");
    define("COL_REZ_TEL", "rez_tel");
    define("COL_REZ_BR", "br_osoba");
    define("COL_REZ_ID", "rez_id");
?>


    
    