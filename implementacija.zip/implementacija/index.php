<!DOCTYPE html>
<html>
<head>
	<title>RESTORAN</title>
	<link rel="stylesheet" href="css/style.css">
	<style>
		body {
		  background-image: url("images/restoran2.jpg");
		}
	</style>
</head>
<body>
	<div style="color:rgb(242, 230, 217)">
			<ul>
				<h1 class="p1"><center>DOBRODOŠLI</center></h1>

				<!--Klikom na MENIJU prebacuje nas na stranicu na kojoj se nalazi meni(nazivi jela, slika jela i cena)-->

				<p class="p2"><h1><center>Ako želite da naručite dostavu hrane možete pogledati u <button> <a href="meni.php" class="myButton">MENIJU</a> </button> šta je u ponudi.</center><h1></p>
								
				<!--Klikom na OVDE prebacuje nas na stranicu za rezervaciju gde unosimo podatke za rezervaciju-->
				<h1><center>Ako želite da rezervišete mesto u restoranu možete to učiniti <button> <a href="rezervacija.php" class="myButton">OVDE</a> </button> ili pozvati na broj 069/123-45-67.</center></h1>
				

				<br><br><br><br><br><br><br>

				<!--Nije implementirana stranica login.php jer implementacija prikazuje kako korisnik koristi ovaj sistem, ali mogu se dodati i funkcionalnosti za vlasnika i menadzera -->
				<h3><center>Ako ste vlasnik restorana ulogujte se <button> <a href="login.php" class="myButton">OVDE</a> </button></a></center></h3>
				<h3><center>Ako ste menadžer restorana ulogujte se <button> <a href="login.php" class="myButton">OVDE</a> </button></a></center></h3>

			</ul>
		</div>
	</div>
</body>
</html>